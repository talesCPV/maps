<?php

	if (IsSet($_POST["path"])){
        $path = $_POST["path"];
        $diretorio = dir($path);
        $resp = "";

        while($arquivo = $diretorio -> read()){
            $nome = explode('.',$arquivo);
            if( strlen($nome[0])){
                $resp = $resp . $nome[0] . ".";
            }
        }
        $diretorio -> close();

        $resp = explode('.',$resp);
        print json_encode($resp);


	}

?>