<!DOCTYPE HTML>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
    <title>theBikeinBox</title>
    <link rel="stylesheet" type="text/css"  href="css/estilo.css" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="js/funcoes.js"></script>
</head>
<body>

    <div class=" cabecalho">
        <p class="logo"> <a href="https://www.thebikeinbox.com.br"><img src="img/logo_thebikeinbox.png"></a></p> <br>
        <p class="title"> APLICATIVO DE SETUP theBikeinBox</p>
        <p>  
        <?php
            include "config/menu.inc";
        ?> 
        </p>       
    </div>



    <div class="form form-page">
        <p> Texto é um conjunto de palavras e frases encadeadas que permitem interpretação e transmitem uma mensagem. É qualquer obra escrita em versão original e que constitui um livro ou um documento escrito. Um texto é uma unidade linguística de extensão superior à frase. </p>
    </div>


</body>
</html>