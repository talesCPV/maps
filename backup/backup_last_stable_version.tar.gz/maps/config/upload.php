<?php

  function metadata($path){
      $xml = simplexml_load_file(getcwd()."/". $path.$_FILES["arquivo"]["name"]);
      $data = date('Y-m-d', strtotime($xml->metadata->time));
      $nome = $xml->trk->name;
      $arquivo = $path.$_FILES["arquivo"]["name"];
      setcookie('file', $path.$_FILES["arquivo"]["name"]); 

      $lat_max = -100;
      $lon_max = -100;
      $lat_min = 100;
      $lon_min = 100;

      foreach($xml->trk->trkseg->trkpt as $trkpoint) {
        if($lat_max < floatval($trkpoint['lat'])){
          $lat_max = floatval ($trkpoint['lat']); 
        }
        if($lon_max < floatval($trkpoint['lon'])){
          $lon_max = floatval ($trkpoint['lon']); 
        } 
        if($lat_min > floatval($trkpoint['lat'])){
          $lat_min = floatval ($trkpoint['lat']); 
        } 
        if($lon_min > floatval($trkpoint['lon'])){
          $lon_min = floatval ($trkpoint['lon']); 
        } 
      
      }

// GRAVA no Banco

      $user = $_COOKIE["usuario"];
      $query = "INSERT INTO tb_files VALUES (DEFAULT,'$user','$nome','$data','$arquivo',$lat_max,$lon_max,$lat_min,$lon_min);";
      include "config/conecta_mysql.inc";
      if (!$conexao)
        die ("Erro de conexão com localhost, o seguinte erro ocorreu -> ".mysql_error());
      mysqli_query($conexao, $query);
    
      $conexao->close();
  }

      if (IsSet($_COOKIE["usuario"]) && IsSet($_FILES["arquivo"])){
        $path = "atleta/".$_COOKIE["usuario"]."/GPX/";
        
        if ( substr($path.$_FILES["arquivo"]["name"],strlen($path.$_FILES["arquivo"]["name"])-1,1) != '/'){
          if(!is_dir($path)){
              //Directory does not exist, so lets create it.
              mkdir($path, 0777, true);
          }   
            copy($_FILES["arquivo"]["tmp_name"],$path.$_FILES["arquivo"]["name"]);
            metadata($path);

            setcookie("file", $path.$_FILES["arquivo"]["name"], time()+3600);

/*
            var now = new Date();
            now.setTime(now.getTime() + 1 * 3600 * 1000);            
            document.cookie = "file="+$('#lbxOpenRole').val()+"; expires=" + now.toUTCString() + "; path=/";
*/

            header('Location: config/refresh_ranking.php?path='.$path.$_FILES["arquivo"]["name"]); 
        }
        
      }
?>